var Data=[];
setTimeout(function() 
	{
		//To know the addon is watching
		function getListings() 
			{
				var d = new Date();	
				var l=[];
				goldListings = document.getElementById("data-table").getElementsByTagName("tbody")[0].querySelectorAll('[role="row"]');
				numberListings = goldListings.length;
				for( var i=0; i<numberListings; i++)
					{
						var gold =goldListings[i].getElementsByTagName("td")[2].innerText;
						var time = goldListings[i].getElementsByTagName("td")[3].innerText;
						var seller = goldListings[i].getElementsByTagName("td")[4].innerText;
						var coins = goldListings[i].getElementsByTagName("td")[6].innerText;
						l.push( [[gold, coins, time, seller], (d.getHours() + ":" + d.getMinutes() +" "+ d.getDate() +"."+d.getMonth()+"."+d.getFullYear() + "\n")] );
					}
				return l;
			}	
		document.getElementsByClassName('sideBtn active')[0].getElementsByTagName('p')[0].click();
		document.getElementsByClassName('sideBtn active')[0].getElementsByTagName('p')[0].click();
		setTimeout( function()
			{
				Data.push( getListings());
				browser.runtime.sendMessage
					({
						greetings: Data.join('\n')
					});
			}, 3000);
		setInterval( function () 
			{
				document.getElementById("refreshListing").click();
				setTimeout( function()
					{
						document.getElementsByClassName('sideBtn active')[0].getElementsByTagName('p')[0].click();
						document.getElementsByClassName('sideBtn active')[0].getElementsByTagName('p')[0].click();
						setTimeout( function()
							{
								Data.push( getListings());
								browser.runtime.sendMessage
								({
									greetings: Data.join('|')
								});
							}, 3000);	
					}, 3000);	
			}, 900000);
	}, 1000);
