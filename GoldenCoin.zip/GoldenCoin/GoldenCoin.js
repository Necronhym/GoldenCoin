
//To know the addon is watching
console.log("Monitoring Gold Prices");
document.body.style.border = "5px solid red";

function getListings() 
	{
		goldListings = document.getElementById("data-table").getElementsByTagName("tbody")[0].querySelectorAll('[role="row"]');
		numberListings = goldListings.length;
		console.log("Number of Listings: " + numberListings);
		for( var i=0; i<numberListings; i++)
			{
				var gold =goldListings[i].getElementsByTagName("td")[2].innerText;
				var time = goldListings[i].getElementsByTagName("td")[3].innerText;
				var seller = goldListings[i].getElementsByTagName("td")[4].innerText;
				var coins = goldListings[i].getElementsByTagName("td")[6].innerText;
				console.log(gold + " " + coins + " " + time + " " + seller);
			}
	}
var d = new Date();	
console.log("Refreshing Auctions, Time: " + d);
document.getElementsByClassName('sideBtn active')[0].getElementsByTagName('p')[0].click();
document.getElementsByClassName('sideBtn active')[0].getElementsByTagName('p')[0].click();
setTimeout( function()
	{
		console.log("Fetching Auction Inforamtion");
		getListings();
	}, 3000);
setInterval( function () 
	{
		document.getElementById("refreshListing").click();
		setTimeout( function()
			{
				var d = new Date();	
				console.log("Refreshing Auctions, Time: " + d);
				document.getElementsByClassName('sideBtn active')[0].getElementsByTagName('p')[0].click();
				document.getElementsByClassName('sideBtn active')[0].getElementsByTagName('p')[0].click();
				setTimeout( function()
					{
						console.log("Fetching Auction Inforamtion");
						getListings();
					}, 3000);	
			}, 3000);	
	}, 1800000);
