var Data = [];
function dl() {
//Data to downlaod:
var downloadData =  URL.createObjectURL(new Blob( [Data.join('\n')] ,{type : "text/plain;charset=utf-8"}));

//Filename:
var d=new Date();
var fn = "Warmane_Trade_Data_" +d.getDate() +"."+(d.getMonth()+1)+"."+d.getFullYear()+".txt";
  browser.downloads.download({
    url: downloadData,
    filename: fn,
    saveAs: true
  });
}
function msg(request, sneder, sendResponse){
	Data.push(request.greetings);
}
browser.browserAction.onClicked.addListener(dl);
browser.runtime.onMessage.addListener(msg);
